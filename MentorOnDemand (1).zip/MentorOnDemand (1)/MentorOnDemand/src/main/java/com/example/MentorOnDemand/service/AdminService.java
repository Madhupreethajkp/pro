package com.example.MentorOnDemand.service;

public interface AdminService {

}
