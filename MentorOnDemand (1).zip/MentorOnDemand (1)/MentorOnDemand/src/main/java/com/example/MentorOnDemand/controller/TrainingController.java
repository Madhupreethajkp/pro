package com.example.MentorOnDemand.controller;

public interface TrainingController {

}
