package com.example.MentorOnDemand.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.MentorOnDemand.model.Technology;
import com.example.MentorOnDemand.model.Training;
import com.example.MentorOnDemand.service.TrainingService;

@Controller
public class TrainingControllerImpl implements TrainingController {
@Autowired
TrainingService trainingService;
@RequestMapping(value="/listRequest")

public ModelAndView getRequestList() throws SQLException{
	ModelAndView mv=new ModelAndView();
	mv.setViewName("listRequest");
	mv.addObject("listRequest", trainingService.getRequestList());
	return mv;
}

@RequestMapping(value="/techAccept")

public  String acceptRequest(@RequestParam("training_id") int training_id,@Validated Training training) 

{
	System.out.println(training_id);
	 Connection cn = null;
     Statement smt = null;
     try {
         Class.forName("com.mysql.jdbc.Driver");
         cn = DriverManager.
                 getConnection("jdbc:mysql://localhost:3306/mentor","root","root");
      
          smt=cn.createStatement();
          String q="Select * from training where training_id='"+training_id+"'";
          ResultSet rs=smt.executeQuery(q);
          String nn="accepted";
          if(rs.next())
			{
        	  String pat="status='"+nn+"'";
        	  q="update training set "+pat+" where training_id='"+training_id+"'";
        	  smt.executeUpdate(q);
			}
}
     catch(Exception e){
    	 System.out.println(e);
     }
     return "mentorLandingPage";
}

@RequestMapping(value="/techReject")

public  String rejectRequest(@RequestParam("training_id") int training_id,@Validated Training training) 

{
	System.out.println(training_id);
	 Connection cn = null;
     Statement smt = null;
     try {
         Class.forName("com.mysql.jdbc.Driver");
         cn = DriverManager.
                 getConnection("jdbc:mysql://localhost:3306/mentor","root","root");
      
          smt=cn.createStatement();
          String q="Select * from training where training_id='"+training_id+"'";
          ResultSet rs=smt.executeQuery(q);
          String nn="rejected";
          if(rs.next())
			{
        	  String pat="status='"+nn+"'";
        	  q="update training set "+pat+" where training_id='"+training_id+"'";
        	  smt.executeUpdate(q);
			}
}
     catch(Exception e){
    	 System.out.println(e);
     }
     return "mentorLandingPage";
}
}